/* sont les commentaires que j'ai ecrits. Je n ai pas des connaissances extraordinaires
* mais je fais ce que je peux avec mes connaissances et mes tests. N hesitez pas a me contacter
* si vous avez des questions : @ChiefDuPAN sur Twitter. J essaierai de vous aider sur ce que je peux.
* Je vous conseille d installer devkitpro (https://github.com/devkitPro/installer/releases),
* des exemples sont fournis avec.
*/

//les librairies n�cessaires

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <switch.h>

//defini les pixels de l'ecran de la switch, 1280 en largeur par 720 en hauteur.
#define FB_WIDTH  1280
#define FB_HEIGHT 720


// Si vous souhaitez du 1920 par 1080
//#define FB_WIDTH  1920
//#define FB_HEIGHT 1080

int main(int argc, char* argv[])
{
	// ecran 'principal' de la Switch
    NWindow* win = nwindowGetDefault();

    // Creation d un framebuffer et definition du format utilise
	// Pour la couleur cela sera en format hexadecimal ABGR (inverse de RGBA)
    Framebuffer fb;
    framebufferCreate(&fb, win, FB_WIDTH, FB_HEIGHT, PIXEL_FORMAT_RGBA_8888, 2);
    framebufferMakeLinear(&fb);

    u32 cnt = 0;
    while (appletMainLoop())
    {
        // Scan des inputs. Execute a chaque frame (1/60 de seconde)
        hidScanInput();

        // recupere information du bouton presse
        u64 kDown = hidKeysDown(CONTROLLER_P1_AUTO);
		
		//condition : si un bouton presse (kDwon) et que c est le '+' (KEY_PLUS) 
		// break de la boucle => fin du programme
        if (kDown & KEY_PLUS)
            break;

        // je sais pas ce que c'est mais c'est utile
        u32 stride;
        u32* framebuf = (u32*) framebufferBegin(&fb, &stride);
		
		// cnt est un compteur de frame. Equivaut au temps max de l animation dans ce code
        if (cnt != 1500)
            cnt ++;
        else
            cnt = 0;
     	
		// boucles qui vont mettre en couleur les pixels. y correspond aux lignes et x aux colonnes
        for (u32 y = 0; y < FB_HEIGHT; y ++)
        {
            for (u32 x = 0; x < FB_WIDTH; x ++)
            {
				// definition d une position : nb de ligne * 1280 + colonne
				//								 y		   * stride + x
				// possec permet de prendre 1 pixel sur 4 et aller plus vite
				// mais utilisez une boucle for(i=0;i<3;i++) pour remplir les 3 pixels suivants
                u32 pos = y * stride / sizeof(u32) + x;
				u32 possec = y* stride / sizeof(u32) +4*x;
				// condition cnt==alpha <=> quand le programme est a la frame alpha
                if (cnt==1){
					// premiere bande blanche
					if(0<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<192){
						framebuf[pos] = 0x01FFFFFF;
					}
					//premiere bougie
					else if(192<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<320){
						if(FB_HEIGHT*FB_WIDTH/2<=pos&&pos<FB_HEIGHT*FB_WIDTH)							
							framebuf[pos] = 0x0100CCFF;
						else if((FB_HEIGHT*FB_WIDTH/2)-80000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2){
							if((245<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<=265))
								framebuf[pos] = 0x01010101;
							else
								framebuf[pos] = 0x01FFFFFF;
						}
						else 
							framebuf[pos] = 0x01FFFFFF;
					}
					//premier espace
					else if(320<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<448){
						framebuf[pos] = 0x01FFFFFF;
					}
					//bougie 2
					else if(448<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<576){
						if(FB_HEIGHT*FB_WIDTH/2<=pos&&pos<FB_HEIGHT*FB_WIDTH)							
							framebuf[pos] = 0x0100CCFF;
						else if((FB_HEIGHT*FB_WIDTH/2)-80000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2){
							if((501<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<=521))
								framebuf[pos] = 0x01010101;
							else
								framebuf[pos] = 0x01FFFFFF;
						}
						else 
							framebuf[pos] = 0x01FFFFFF;
					}
					//espace 2
					else if(576<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<704){
						framebuf[pos] = 0x01FFFFFF;
					}
					//bougie 3
					else if(704<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<832){
						if(FB_HEIGHT*FB_WIDTH/2<=pos&&pos<FB_HEIGHT*FB_WIDTH)							
							framebuf[pos] = 0x0100CCFF;
						else if((FB_HEIGHT*FB_WIDTH/2)-80000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2){
							if((757<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<=777))
								framebuf[pos] = 0x01010101;
							else
								framebuf[pos] = 0x01FFFFFF;
						}
						else 
							framebuf[pos] = 0x01FFFFFF;
					}
					//espace 3
					else if(832<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<960){
						framebuf[pos] = 0x01FFFFFF;
					}
					//bougie 4
					else if(960<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<1088){
						if(FB_HEIGHT*FB_WIDTH/2<=pos&&pos<FB_HEIGHT*FB_WIDTH)							
							framebuf[pos] = 0x0100CCFF;
						else if((FB_HEIGHT*FB_WIDTH/2)-80000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2){
							if((1013<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<=1033))
								framebuf[pos] = 0x01010101;
							else
								framebuf[pos] = 0x01FFFFFF;
						}
						else 
							framebuf[pos] = 0x01FFFFFF;
					}
					//bande 2
					else{
						framebuf[pos] = 0x01FFFFFF;
					}
				}
				//flammes 1 sur la droite
				if (cnt==1){
					if(230<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<290){
						if((FB_HEIGHT*FB_WIDTH/2)-240000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-80000){
							framebuf[pos] = 0x0100CCFF;
						}
						if(((FB_HEIGHT*FB_WIDTH/2)-210000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-110000)&&(245<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<275)){
							framebuf[pos] = 0x010033FF;
						}
					}
					if(486<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<546){
						if((FB_HEIGHT*FB_WIDTH/2)-240000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-80000){
							framebuf[pos] = 0x0100CCFF;
						}
						if(((FB_HEIGHT*FB_WIDTH/2)-210000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-110000)&&(501<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<531)){
							framebuf[pos] = 0x010033FF;
						}
					}
					if(742<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<802){
						if((FB_HEIGHT*FB_WIDTH/2)-240000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-80000){
							framebuf[pos] = 0x0100CCFF;
						}
						if(((FB_HEIGHT*FB_WIDTH/2)-210000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-110000)&&(757<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<787)){
							framebuf[pos] = 0x010033FF;
						}
					}
					if(998<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<1058){
						if((FB_HEIGHT*FB_WIDTH/2)-240000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-80000){
							framebuf[pos] = 0x0100CCFF;
						}
						if(((FB_HEIGHT*FB_WIDTH/2)-210000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-110000)&&(1013<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<1043)){
							framebuf[pos] = 0x010033FF;
						}
					}
				}
				//flammes 2 sur la gauche
				if(cnt==60){
					if(220<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<290){
						if((FB_HEIGHT*FB_WIDTH/2)-240000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-80000){
							if(pos%FB_WIDTH>=280)
								framebuf[pos] = 0x01FFFFFF;
							else
								framebuf[pos] = 0x0100CCFF;
							if(((FB_HEIGHT*FB_WIDTH/2)-210000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-110000)&&(235<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<265)){
								framebuf[pos] = 0x010033FF;
							}
						}
					}
					if(476<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<546){
						if((FB_HEIGHT*FB_WIDTH/2)-240000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-80000){
							if(pos%FB_WIDTH>=536)
								framebuf[pos] = 0x01FFFFFF;
							else
								framebuf[pos] = 0x0100CCFF;
							if(((FB_HEIGHT*FB_WIDTH/2)-210000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-110000)&&(491<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<521)){
								framebuf[pos] = 0x010033FF;
							}
						}
					}
					if(732<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<802){
						if((FB_HEIGHT*FB_WIDTH/2)-240000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-80000){
							if(pos%FB_WIDTH>=792)
								framebuf[pos] = 0x01FFFFFF;
							else
								framebuf[pos] = 0x0100CCFF;
							if(((FB_HEIGHT*FB_WIDTH/2)-210000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-110000)&&(747<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<=777)){
								framebuf[pos] = 0x010033FF;
							}
						}
					}
					if(988<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<1058){
						if((FB_HEIGHT*FB_WIDTH/2)-240000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-80000){
							if(pos%FB_WIDTH>=1048)
								framebuf[pos] = 0x01FFFFFF;
							else
								framebuf[pos] = 0x0100CCFF;
							if(((FB_HEIGHT*FB_WIDTH/2)-210000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-110000)&&(1003<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<1033)){
								framebuf[pos] = 0x010033FF;
							}
						}
					}
				}
				//flammes 3 sur la droite
				if(cnt==120){
					if(220<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<290){
						if((FB_HEIGHT*FB_WIDTH/2)-240000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-80000){
							if(pos%FB_WIDTH<=230)
								framebuf[pos] = 0x01FFFFFF;
							else
								framebuf[pos] = 0x0100CCFF;
							if(((FB_HEIGHT*FB_WIDTH/2)-210000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-110000)&&(245<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<275)){
								framebuf[pos] = 0x010033FF;
							}
						}
					}
					if(476<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<546){
						if((FB_HEIGHT*FB_WIDTH/2)-240000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-80000){
							if(pos%FB_WIDTH<=486)
								framebuf[pos] = 0x01FFFFFF;
							else
								framebuf[pos] = 0x0100CCFF;
							if(((FB_HEIGHT*FB_WIDTH/2)-210000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-110000)&&(501<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<531)){
								framebuf[pos] = 0x010033FF;
							}
						}
					}
					if(732<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<802){
						if((FB_HEIGHT*FB_WIDTH/2)-240000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-80000){
							if(pos%FB_WIDTH<=742)
								framebuf[pos] = 0x01FFFFFF;
							else
								framebuf[pos] = 0x0100CCFF;
							if(((FB_HEIGHT*FB_WIDTH/2)-210000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-110000)&&(757<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<787)){
								framebuf[pos] = 0x010033FF;
							}
						}
					}
					if(988<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<1058){
						if((FB_HEIGHT*FB_WIDTH/2)-240000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-80000){
							if(pos%FB_WIDTH<=998)
								framebuf[pos] = 0x01FFFFFF;
							else
								framebuf[pos] = 0x0100CCFF;
							if(((FB_HEIGHT*FB_WIDTH/2)-210000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-110000)&&(1013<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<1043)){
								framebuf[pos] = 0x010033FF;
							}
						}
					}
				}
				//flammes 4 sur la gauche
				if(cnt==180){
					if(476<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<546){
						if((FB_HEIGHT*FB_WIDTH/2)-240000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-80000){
							if(pos%FB_WIDTH>=536)
								framebuf[pos] = 0x01FFFFFF;
							else
								framebuf[pos] = 0x0100CCFF;
							if(((FB_HEIGHT*FB_WIDTH/2)-210000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-110000)&&(491<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<521)){
								framebuf[pos] = 0x010033FF;
							}
						}
					}
					if(732<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<802){
						if((FB_HEIGHT*FB_WIDTH/2)-240000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-80000){
							if(pos%FB_WIDTH>=792)
								framebuf[pos] = 0x01FFFFFF;
							else
								framebuf[pos] = 0x0100CCFF;
							if(((FB_HEIGHT*FB_WIDTH/2)-210000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-110000)&&(747<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<=777)){
								framebuf[pos] = 0x010033FF;
							}
						}
					}
					if(988<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<1058){
						if((FB_HEIGHT*FB_WIDTH/2)-240000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-80000){
							if(pos%FB_WIDTH>=1048)
								framebuf[pos] = 0x01FFFFFF;
							else
								framebuf[pos] = 0x0100CCFF;
							if(((FB_HEIGHT*FB_WIDTH/2)-210000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-110000)&&(1003<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<1033)){
								framebuf[pos] = 0x010033FF;
							}
						}
					}
				}
				//flammes 5 sur la droite
				if(cnt==240){
					if(732<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<802){
						if((FB_HEIGHT*FB_WIDTH/2)-240000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-80000){
							if(pos%FB_WIDTH<=742)
								framebuf[pos] = 0x01FFFFFF;
							else
								framebuf[pos] = 0x0100CCFF;
							if(((FB_HEIGHT*FB_WIDTH/2)-210000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-110000)&&(757<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<787)){
								framebuf[pos] = 0x010033FF;
							}
						}
					}
					if(988<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<1058){
						if((FB_HEIGHT*FB_WIDTH/2)-240000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-80000){
							if(pos%FB_WIDTH<=998)
								framebuf[pos] = 0x01FFFFFF;
							else
								framebuf[pos] = 0x0100CCFF;
							if(((FB_HEIGHT*FB_WIDTH/2)-210000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-110000)&&(1013<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<=1043)){
								framebuf[pos] = 0x010033FF;
							}
						}
					}
				}
				//flammes 6 sur la gauche
				if(cnt==300){
					if(988<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<1058){
						if((FB_HEIGHT*FB_WIDTH/2)-240000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-80000){
							if(pos%FB_WIDTH>=1048)
								framebuf[pos] = 0x01FFFFFF;
							else
								framebuf[pos] = 0x0100CCFF;
							if(((FB_HEIGHT*FB_WIDTH/2)-210000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-110000)&&(1003<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<1033)){
								framebuf[pos] = 0x010033FF;
							}
						}
					}
				}
				//creation de l'arc-en-ciel et avance
				if (120<=cnt&&cnt<440){
					if (x<=cnt-120){
							if((FB_HEIGHT*FB_WIDTH/2)-260000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-200000){
								for(int i=0;i<4;i++){
									framebuf[possec+i] = 0x01FFFFFF;
								}
							}
							if((FB_HEIGHT*FB_WIDTH/2)-200000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-180000){
								for(int i=0;i<4;i++){
									framebuf[possec+i] = 0x010000FF;
								}
							}
							else if((FB_HEIGHT*FB_WIDTH/2)-180000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-160000){
								for(int i=0;i<4;i++){
									framebuf[possec+i] = 0x010066FF;
								}
							}
							else if((FB_HEIGHT*FB_WIDTH/2)-160000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-140000){
								for(int i=0;i<4;i++){
									framebuf[possec+i] = 0x0100FFFF;
								}
							}
							else if((FB_HEIGHT*FB_WIDTH/2)-140000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-120000){
								for(int i=0;i<4;i++){
									framebuf[possec+i] = 0x0100FF00;
								}
							}
							else if((FB_HEIGHT*FB_WIDTH/2)-120000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-100000){
								for(int i=0;i<4;i++){
									framebuf[possec+i] = 0x01999933;
								}
							}
							else if((FB_HEIGHT*FB_WIDTH/2)-100000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-80000){
								for(int i=0;i<4;i++){
									framebuf[possec+i] = 0x01FF0066;
								}
							}
					}
				}
				// bande blanche derriere l'arc-en-ciel pour 'effacer' les couleurs
				if (180<=cnt&&cnt<500){
					if(x<=cnt-180){
						if((FB_HEIGHT*FB_WIDTH/2)-200000<=pos&&pos<FB_HEIGHT*FB_WIDTH/2-80000){
							for(int i=0;i<4;i++){
								framebuf[possec+i] = 0x01FFFFFF;
							}
						}
					}
				}
				// fondu noir de la fin
				if(500<=cnt&&cnt<=820){
					if(640-(cnt-480)<=(pos%FB_WIDTH)&&(pos%FB_WIDTH)<=641+(cnt-480)){
						framebuf[pos] = 0x01010101;
					}
					if((pos%FB_WIDTH)<=(cnt-500)){
						framebuf[pos] = 0x01010101;
					}
					if((pos%FB_WIDTH)>=1279-(cnt-500)){
						framebuf[pos]= 0x01010101;
					}
				}
				// coeur de la fin
				if (cnt==822){
					int posth=230400+(1280*17/32);
					int j,i;
					for(j=0;j<180;j++){
						for(i=0;i<3;i++){
							framebuf[posth+i] = 0x01FFFFFF;
						}
						posth=posth+1281;
					}
					for(j=0;j<179;j++){
						for(i=0;i<3;i++){
							framebuf[posth-i] = 0x01FFFFFF;
						}
							posth=posth+1279;
					}
					posth=230400+(1280*15/32);
					for(j=0;j<180;j++){
						framebuf[posth-j] = 0x01FFFFFF;
					}
					posth=posth-180;
					for(j=0;j<360;j++){
						framebuf[posth+(j*1280)]= 0x01FFFFFF;
					}
					posth=posth+180*1280;
					for(j=0;j<180;j++){
						framebuf[posth+j] = 0x01FFFFFF;
					}
					posth=posth+180*1280;
					for(j=0;j<180;j++){
						framebuf[posth+j] = 0x01FFFFFF;
					}
				}
            }//fin boucle 2
        }//fin boucle 1

        framebufferEnd(&fb);
    }

    framebufferClose(&fb);
    return 0;
}
